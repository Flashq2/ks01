<?php

namespace Illuminate\Database;

use PDOException;

class DeadlockException extends PDOException
{
    //
}
